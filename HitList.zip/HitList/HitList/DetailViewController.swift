//
//  DetailViewController.swift
//  HitList
//
//  Created by Drish on 21/07/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit
import CoreData

class DetailViewController: UIViewController {
    var name : String?
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var lblName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        lblName.text = name
    }
    @IBAction func updateAction(_ sender: Any) {
      
        var people: [NSManagedObject] = []
                guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                      return
                  }
                  let managedContext = appDelegate.persistentContainer.viewContext
                  //2
                  let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Person")
                  //3
                  do {
                    people = try managedContext.fetch(fetchRequest)
                   for item in people{
                       if(   item.value(forKeyPath: "name") as? String == name){
                        item.setValue(txtName.text, forKeyPath: "name")
                           try? managedContext.save()
                           navigationController?.popViewController(animated: false)
                       }
                   }
                  } catch let error as NSError {
                    print("Could not fetch. \(error), \(error.userInfo)")
                  }
    }
    @IBAction func deleteAction(_ sender: Any)
    {
         var people: [NSManagedObject] = []
         guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
               return
           }
           let managedContext = appDelegate.persistentContainer.viewContext
           //2
           let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Person")
           //3
           do {
             people = try managedContext.fetch(fetchRequest)
            for item in people{
                if(   item.value(forKeyPath: "name") as? String == name){
                    managedContext.delete(item)
                    try? managedContext.save()
                    navigationController?.popViewController(animated: false)
                }
            }
           } catch let error as NSError {
             print("Could not fetch. \(error), \(error.userInfo)")
           }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
